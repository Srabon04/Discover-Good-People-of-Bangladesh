CREATE TABLE IF NOT EXISTS nominations (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 nominee_type TEXT NOT NULL,
 name TEXT NOT NULL,
 district TEXT NOT NULL,
 category TEXT NOT NULL,
 statement TEXT NOT NULL,
 description TEXT NOT NULL,
 evidence_url TEXT,
 image_key TEXT,
 status TEXT NOT NULL DEFAULT 'pending',
 reviewer_note TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_nom_status ON nominations(status);
CREATE INDEX IF NOT EXISTS idx_nom_district ON nominations(district);
CREATE INDEX IF NOT EXISTS idx_nom_category ON nominations(category);
CREATE INDEX IF NOT EXISTS idx_nom_name ON nominations(name);

CREATE TABLE IF NOT EXISTS admins (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS sessions (
 token_hash TEXT PRIMARY KEY,
 username TEXT NOT NULL,
 expires_at INTEGER NOT NULL
);
