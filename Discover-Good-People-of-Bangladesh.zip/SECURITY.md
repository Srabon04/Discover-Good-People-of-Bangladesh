# Production security checklist

- Use long random SESSION_SECRET.
- Store ADMIN_PASSWORD_HASH as a Cloudflare secret; never commit passwords.
- Use HTTPS/custom domain.
- Keep R2 private where possible and serve controlled downloads.
- Add Cloudflare WAF/rate limits.
- Review all nomination evidence before approval.
- Restrict admin endpoints to authenticated sessions.
- Rotate secrets periodically.
- Export/backup D1 data regularly.
- Remove demo data before launch.
