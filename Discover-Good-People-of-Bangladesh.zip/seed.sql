INSERT OR IGNORE INTO nominations
(nominee_type,name,district,category,statement,description,status)
VALUES
('person','Demo Verified Profile','ঢাকা','শিক্ষা','ভালো কাজ শুরু হয় নিজের জায়গা থেকে।','এটি একটি demo profile; production launch-এর আগে সরিয়ে দিন।','approved');
