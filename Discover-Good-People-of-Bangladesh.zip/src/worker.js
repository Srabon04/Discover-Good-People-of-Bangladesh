const json = (data, status=200, extra={}) =>
  new Response(JSON.stringify(data), {status, headers:{"content-type":"application/json; charset=utf-8", ...extra}});

const districts = ["ঢাকা","গাজীপুর","নারায়ণগঞ্জ","নরসিংদী","মুন্সিগঞ্জ","মানিকগঞ্জ","মাদারীপুর","রাজবাড়ী","ফরিদপুর","গোপালগঞ্জ","কিশোরগঞ্জ","টাঙ্গাইল","চট্টগ্রাম","কক্সবাজার","কুমিল্লা","ফেনী","ব্রাহ্মণবাড়িয়া","চাঁদপুর","লক্ষ্মীপুর","নোয়াখালী","খাগড়াছড়ি","রাঙামাটি","বান্দরবান","রাজশাহী","বগুড়া","জয়পুরহাট","নওগাঁ","নাটোর","চাঁপাইনবাবগঞ্জ","পাবনা","সিরাজগঞ্জ","খুলনা","বাগেরহাট","সাতক্ষীরা","যশোর","ঝিনাইদহ","মাগুরা","নড়াইল","কুষ্টিয়া","চুয়াডাঙ্গা","মেহেরপুর","বরিশাল","ভোলা","ঝালকাঠি","পটুয়াখালী","পিরোজপুর","সিলেট","মৌলভীবাজার","হবিগঞ্জ","সুনামগঞ্জ","রংপুর","দিনাজপুর","ঠাকুরগাঁও","পঞ্চগড়","নীলফামারী","লালমনিরহাট","কুড়িগ্রাম","গাইবান্ধা","ময়মনসিংহ","জামালপুর","নেত্রকোণা","শেরপুর"];

function headers() {
  return {
    "x-content-type-options":"nosniff",
    "x-frame-options":"DENY",
    "referrer-policy":"strict-origin-when-cross-origin",
    "permissions-policy":"camera=(), microphone=(), geolocation=()",
    "content-security-policy":"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self'; frame-ancestors 'none'"
  };
}
async function sha256(s){return [...new Uint8Array(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(s)))].map(x=>x.toString(16).padStart(2,"0")).join("")}
async function makeToken(secret){return sha256(secret+"|"+crypto.randomUUID()+"|"+Date.now())}
async function requireAdmin(request,env){
  const c=request.headers.get("cookie")||"";
  const m=c.match(/gwb_session=([^;]+)/);
  if(!m) return null;
  const h=await sha256(m[1]);
  const row=await env.DB.prepare("SELECT username,expires_at FROM sessions WHERE token_hash=?").bind(h).first();
  if(!row || row.expires_at < Date.now()){ if(row) await env.DB.prepare("DELETE FROM sessions WHERE token_hash=?").bind(h).run(); return null; }
  return row.username;
}
function rateKey(request){ return request.headers.get("cf-connecting-ip") || "unknown"; }

export default {
 async fetch(request,env){
  const url=new URL(request.url);
  const baseHeaders=headers();

  if(url.pathname==="/healthz") return json({ok:true,service:"good-work-bangladesh"},200,baseHeaders);
  if(url.pathname==="/api/districts") return json(districts,200,baseHeaders);

  if(url.pathname==="/api/search" && request.method==="GET"){
    const q=(url.searchParams.get("q")||"").trim();
    const district=(url.searchParams.get("district")||"").trim();
    const category=(url.searchParams.get("category")||"").trim();
    let sql="SELECT id,nominee_type,name,district,category,statement,description,image_key FROM nominations WHERE status='approved'";
    const args=[];
    if(q){sql+=" AND (name LIKE ? OR statement LIKE ? OR description LIKE ? OR category LIKE ?)"; const x=`%${q}%`; args.push(x,x,x,x);}
    if(district){sql+=" AND district=?";args.push(district)}
    if(category){sql+=" AND category=?";args.push(category)}
    sql+=" ORDER BY created_at DESC LIMIT 100";
    const r=await env.DB.prepare(sql).bind(...args).all();
    return json(r.results||[],200,baseHeaders);
  }

  if(url.pathname==="/api/nominate" && request.method==="POST"){
    const ip=rateKey(request);
    const key="nom:"+ip; env.__rate ||= new Map();
    const now=Date.now(), last=env.__rate.get(key)||0;
    if(now-last<30000) return json({error:"Please wait before submitting again."},429,baseHeaders);
    env.__rate.set(key,now);
    let b; try{b=await request.json()}catch{return json({error:"Invalid JSON"},400,baseHeaders)}
    for(const k of ["nominee_type","name","district","category","statement","description"]) if(!b[k]) return json({error:"Missing field: "+k},400,baseHeaders);
    if(!districts.includes(b.district)) return json({error:"Invalid district"},400,baseHeaders);
    if(!["person","organization","project"].includes(b.nominee_type)) return json({error:"Invalid type"},400,baseHeaders);
    if(String(b.name).length>160 || String(b.statement).length>1000 || String(b.description).length>5000) return json({error:"Input too long"},400,baseHeaders);
    const ev=b.evidence_url?String(b.evidence_url).trim():null;
    if(ev && !/^https?:\/\//i.test(ev)) return json({error:"Evidence URL must start with http:// or https://"},400,baseHeaders);
    await env.DB.prepare(`INSERT INTO nominations(nominee_type,name,district,category,statement,description,evidence_url) VALUES(?,?,?,?,?,?,?)`)
      .bind(b.nominee_type,String(b.name).trim(),b.district,String(b.category).trim(),String(b.statement).trim(),String(b.description).trim(),ev).run();
    return json({ok:true,message:"আপনার nomination গ্রহণ করা হয়েছে। Verification-এর পর প্রকাশ করা হবে।"},201,baseHeaders);
  }

  if(url.pathname==="/api/admin/login" && request.method==="POST"){
    const b=await request.json().catch(()=>null); if(!b) return json({error:"Invalid JSON"},400,baseHeaders);
    if(b.username!==env.ADMIN_USERNAME || !b.password) return json({error:"Invalid credentials"},401,baseHeaders);
    // ADMIN_PASSWORD_HASH is SHA-256(password). For stronger password storage, use an external identity provider or PBKDF2-derived secret.
    const ph=await sha256(b.password);
    if(ph!==env.ADMIN_PASSWORD_HASH) return json({error:"Invalid credentials"},401,baseHeaders);
    const token=await makeToken(env.SESSION_SECRET);
    const hash=await sha256(token); const exp=Date.now()+8*60*60*1000;
    await env.DB.prepare("INSERT INTO sessions(token_hash,username,expires_at) VALUES(?,?,?)").bind(hash,b.username,exp).run();
    return json({ok:true},200,{...baseHeaders,"set-cookie":`gwb_session=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=28800`});
  }

  if(url.pathname==="/api/admin/logout"){
    const c=request.headers.get("cookie")||"",m=c.match(/gwb_session=([^;]+)/);
    if(m) await env.DB.prepare("DELETE FROM sessions WHERE token_hash=?").bind(await sha256(m[1])).run();
    return json({ok:true},200,{...baseHeaders,"set-cookie":"gwb_session=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0"});
  }

  if(url.pathname.startsWith("/api/admin/")){
    const admin=await requireAdmin(request,env);
    if(!admin) return json({error:"Unauthorized"},401,baseHeaders);
    if(url.pathname==="/api/admin/nominations"){
      const status=url.searchParams.get("status")||"pending";
      const r=await env.DB.prepare("SELECT * FROM nominations WHERE status=? ORDER BY created_at DESC LIMIT 200").bind(status).all();
      return json(r.results||[],200,baseHeaders);
    }
    const m=url.pathname.match(/^\/api\/admin\/nominations\/(\d+)$/);
    if(m && request.method==="PATCH"){
      const id=Number(m[1]); const b=await request.json();
      if(!["pending","approved","rejected"].includes(b.status)) return json({error:"Invalid status"},400,baseHeaders);
      await env.DB.prepare("UPDATE nominations SET status=?,reviewer_note=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").bind(b.status,String(b.reviewer_note||"").slice(0,2000),id).run();
      return json({ok:true},200,baseHeaders);
    }
  }

  if(url.pathname==="/api/admin/upload" && request.method==="POST"){
    const admin=await requireAdmin(request,env); if(!admin) return json({error:"Unauthorized"},401,baseHeaders);
    const ct=request.headers.get("content-type")||"";
    if(!ct.startsWith("image/")) return json({error:"Send an image/* body"},415,baseHeaders);
    const len=Number(request.headers.get("content-length")||0); if(len>5*1024*1024) return json({error:"Max 5MB"},413,baseHeaders);
    const ext=ct.includes("png")?".png":ct.includes("webp")?".webp":".jpg";
    const key=`nominations/${crypto.randomUUID()}${ext}`;
    await env.UPLOADS.put(key,request.body,{httpMetadata:{contentType:ct}});
    return json({ok:true,key},201,baseHeaders);
  }

  return new Response(null,{status:404,headers:baseHeaders});
 }
};
