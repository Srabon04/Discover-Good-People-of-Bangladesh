# Good Work Bangladesh — Complete Cloudflare Edition

A production-oriented starter for a verified Good Work recognition platform.

Included:
- Public Bengali website
- Nomination form
- 64 Bangladesh districts
- Search and district/category filters
- Admin login/session architecture
- Admin review: pending / approved / rejected + reviewer notes
- D1 database schema and seed
- R2 image storage endpoint
- Security headers, rate limiting, input validation
- Cloudflare Worker API + static assets
- Deployment configuration
- Backup/security guidance

## Deploy
1. Create a Cloudflare account and a GitHub repository.
2. Create a D1 database named `good-work-bangladesh`.
3. Create an R2 bucket named `good-work-bangladesh-uploads`.
4. Put the returned D1 database ID into `wrangler.toml`.
5. Run the schema against D1:
   `npx wrangler d1 execute good-work-bangladesh --remote --file=./schema.sql`
6. Set secrets:
   `npx wrangler secret put ADMIN_USERNAME`
   `npx wrangler secret put ADMIN_PASSWORD_HASH`
   `npx wrangler secret put SESSION_SECRET`
7. Deploy:
   `npx wrangler deploy`
8. Open the generated `workers.dev` address.
9. Add your custom domain later from Cloudflare.

## Important
This package cannot create or access your Cloudflare account for you. Replace all placeholders and set strong secrets before public launch.
